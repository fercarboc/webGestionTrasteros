import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Box, Phone, Mail, MapPin, ShieldCheck } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const isBookingPage = location.pathname === '/reservar';

  return (
    <div className="flex flex-col min-h-screen font-sans text-slate-800">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="bg-brand-600 p-2 rounded-lg text-white group-hover:bg-brand-700 transition-colors">
                <Box size={28} strokeWidth={2.5} />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-slate-900 leading-none">webCantabria</span>
                <span className="text-sm font-semibold text-brand-600 tracking-wide uppercase">Storage</span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-8">
              {!isBookingPage && (
                <>
                  <a href="#beneficios" className="font-medium text-slate-600 hover:text-brand-600 transition">Beneficios</a>
                  <a href="#tamanos" className="font-medium text-slate-600 hover:text-brand-600 transition">Tamaños</a>
                  <a href="#ubicacion" className="font-medium text-slate-600 hover:text-brand-600 transition">Ubicación</a>
                </>
              )}
              <Link 
                to="/reservar" 
                className="bg-brand-600 text-white px-6 py-2.5 rounded-full font-semibold shadow-lg shadow-brand-500/30 hover:bg-brand-700 hover:shadow-brand-500/40 transition-all transform hover:-translate-y-0.5"
              >
                Reservar Online
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 text-slate-600"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 absolute w-full left-0 shadow-lg">
            <div className="px-4 py-4 space-y-4 flex flex-col">
               {!isBookingPage && (
                <>
                  <a href="#beneficios" onClick={() => setIsMobileMenuOpen(false)} className="block text-lg font-medium text-slate-600">Beneficios</a>
                  <a href="#tamanos" onClick={() => setIsMobileMenuOpen(false)} className="block text-lg font-medium text-slate-600">Tamaños</a>
                </>
              )}
              <Link 
                to="/reservar" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="block text-center w-full bg-brand-600 text-white px-6 py-3 rounded-lg font-bold"
              >
                Reservar Ahora
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            
            {/* Brand */}
            <div>
               <div className="flex items-center gap-2 mb-4 text-white">
                <Box className="text-brand-500" size={24} />
                <span className="text-xl font-bold">webCantabriaStorage</span>
              </div>
              <p className="text-sm leading-relaxed mb-6 text-slate-400">
                Líderes en almacenamiento profesional en Cantabria. 
                Soluciones flexibles para particulares y empresas con la máxima seguridad garantizada.
              </p>
              <div className="flex items-center gap-2 text-brand-400 font-semibold">
                <ShieldCheck size={20} />
                <span>Seguro Multirriesgo Incluido</span>
              </div>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Contacto</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <MapPin className="text-brand-500 mt-1" size={18} />
                  <span>Polígono Industrial La Verde, Nave 4,<br/>39600 Camargo, Cantabria</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="text-brand-500" size={18} />
                  <a href="tel:+34942000000" className="hover:text-white transition">942 00 00 00</a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="text-brand-500" size={18} />
                  <a href="mailto:info@webcantabriastorage.com" className="hover:text-white transition">info@webcantabriastorage.com</a>
                </li>
              </ul>
            </div>

            {/* Links */}
            <div>
              <h3 className="text-white font-bold text-lg mb-4">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-brand-400 transition">Aviso Legal</a></li>
                <li><a href="#" className="hover:text-brand-400 transition">Política de Privacidad</a></li>
                <li><a href="#" className="hover:text-brand-400 transition">Condiciones de Contratación</a></li>
                <li><a href="#" className="hover:text-brand-400 transition">Política de Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-12 pt-8 text-center text-sm text-slate-500">
            &copy; {new Date().getFullYear()} webCantabriaStorage. Todos los derechos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
};