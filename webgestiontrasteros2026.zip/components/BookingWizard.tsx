import React, { useState, useEffect } from 'react';
import { X, CheckCircle, CreditCard, Calendar, User, ShieldCheck } from 'lucide-react';
import { Button } from './Button';
import { STORAGE_UNITS } from '../constants';
import { BookingStep, CustomerInfo, BookingData, StorageUnit } from '../types';

interface BookingWizardProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedUnitId?: string | null;
}

export const BookingWizard: React.FC<BookingWizardProps> = ({ isOpen, onClose, preSelectedUnitId }) => {
  const [step, setStep] = useState<BookingStep>(BookingStep.SELECT_UNIT);
  const [data, setData] = useState<BookingData>({
    unitId: preSelectedUnitId || null,
    startDate: '',
    paymentMethod: 'card',
    customer: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dni: '',
      address: '',
    }
  });
  const [isProcessing, setIsProcessing] = useState(false);

  // Effect to update unit if prop changes or on open
  useEffect(() => {
    if (isOpen) {
      if (preSelectedUnitId) {
        setData(prev => ({ ...prev, unitId: preSelectedUnitId }));
        setStep(BookingStep.SELECT_DATES);
      } else {
        setStep(BookingStep.SELECT_UNIT);
      }
    }
  }, [isOpen, preSelectedUnitId]);

  if (!isOpen) return null;

  const handleNext = () => {
    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    setStep(prev => prev - 1);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setData(prev => ({
      ...prev,
      customer: { ...prev.customer, [name]: value }
    }));
  };

  const simulatePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      handleNext();
    }, 2000);
  };

  const selectedUnit = STORAGE_UNITS.find(u => u.id === data.unitId);

  // Render Step Content
  const renderStep = () => {
    switch (step) {
      case BookingStep.SELECT_UNIT:
        return (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto p-2">
            {STORAGE_UNITS.map((unit) => (
              <div 
                key={unit.id}
                onClick={() => {
                    setData({...data, unitId: unit.id});
                    handleNext();
                }}
                className={`cursor-pointer border-2 rounded-xl p-4 transition-all hover:shadow-md ${data.unitId === unit.id ? 'border-accent-500 bg-accent-50' : 'border-gray-200 hover:border-brand-300'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-lg text-brand-900">{unit.sizeLabel}</span>
                  <span className="bg-brand-100 text-brand-800 text-xs px-2 py-1 rounded-full font-semibold">{unit.area}</span>
                </div>
                <div className="text-2xl font-bold text-accent-600 mb-2">{unit.price}€<span className="text-sm text-gray-500 font-normal">/mes</span></div>
                <p className="text-sm text-gray-600">{unit.description}</p>
              </div>
            ))}
          </div>
        );

      case BookingStep.SELECT_DATES:
        return (
          <div className="space-y-6 py-4">
            <div className="bg-blue-50 p-4 rounded-lg flex items-center space-x-3">
               <ShieldCheck className="text-brand-600 h-6 w-6" />
               <div>
                 <p className="font-medium text-brand-900">Tu selección: {selectedUnit?.sizeLabel} ({selectedUnit?.area})</p>
                 <p className="text-sm text-brand-700">{selectedUnit?.price}€ / mes (IVA incluido)</p>
               </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">¿Cuándo quieres empezar?</label>
              <input 
                type="date" 
                value={data.startDate}
                onChange={(e) => setData({...data, startDate: e.target.value})}
                className="w-full border-gray-300 border rounded-lg p-3 focus:ring-2 focus:ring-accent-500 focus:border-accent-500 outline-none"
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
            <p className="text-sm text-gray-500 italic">
              * El contrato se renueva mensualmente de forma automática. Puedes cancelar con 15 días de antelación.
            </p>
          </div>
        );

      case BookingStep.PERSONAL_INFO:
        return (
          <div className="space-y-4 py-2 max-h-[60vh] overflow-y-auto">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                <input required name="firstName" value={data.customer.firstName} onChange={handleInputChange} className="w-full border p-2 rounded-lg" placeholder="Juan" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Apellidos</label>
                <input required name="lastName" value={data.customer.lastName} onChange={handleInputChange} className="w-full border p-2 rounded-lg" placeholder="Pérez" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input required type="email" name="email" value={data.customer.email} onChange={handleInputChange} className="w-full border p-2 rounded-lg" placeholder="juan@ejemplo.com" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Teléfono</label>
                <input required type="tel" name="phone" value={data.customer.phone} onChange={handleInputChange} className="w-full border p-2 rounded-lg" placeholder="600 000 000" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">DNI/NIF</label>
                <input required name="dni" value={data.customer.dni} onChange={handleInputChange} className="w-full border p-2 rounded-lg" placeholder="12345678X" />
              </div>
            </div>
             <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Dirección Completa</label>
              <input required name="address" value={data.customer.address} onChange={handleInputChange} className="w-full border p-2 rounded-lg" placeholder="Calle Principal 1, Santander" />
            </div>
          </div>
        );

      case BookingStep.PAYMENT:
        return (
          <div className="space-y-6 py-4">
             <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">Resumen del pedido</h4>
                <div className="flex justify-between text-sm mb-1">
                    <span>Trastero {selectedUnit?.sizeLabel}</span>
                    <span>{selectedUnit?.price}€</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                    <span>Seguro básico</span>
                    <span className="text-green-600">Incluido</span>
                </div>
                 <div className="flex justify-between text-sm mb-1">
                    <span>IVA (21%)</span>
                    <span>{(selectedUnit!.price * 0.21).toFixed(2)}€</span>
                </div>
                <div className="border-t border-gray-200 my-2 pt-2 flex justify-between font-bold text-lg">
                    <span>Total a pagar hoy</span>
                    <span>{(selectedUnit!.price * 1.21).toFixed(2)}€</span>
                </div>
             </div>

             <div className="border rounded-lg p-4 cursor-pointer border-accent-500 bg-accent-50 relative">
                <div className="absolute top-2 right-2 text-accent-600"><CheckCircle size={20}/></div>
                <div className="flex items-center space-x-3 mb-4">
                    <CreditCard className="text-gray-700"/>
                    <span className="font-medium">Tarjeta de Crédito / Débito</span>
                </div>
                {/* Fake Credit Card Form */}
                <div className="space-y-3 opacity-75 pointer-events-none">
                    <input className="w-full border p-2 rounded" placeholder="0000 0000 0000 0000" disabled />
                    <div className="grid grid-cols-2 gap-3">
                         <input className="border p-2 rounded" placeholder="MM/AA" disabled />
                         <input className="border p-2 rounded" placeholder="CVC" disabled />
                    </div>
                </div>
             </div>
             <p className="text-xs text-center text-gray-500">
                <span className="flex items-center justify-center gap-1"><ShieldCheck size={12}/> Pago 100% seguro y encriptado.</span>
             </p>
          </div>
        );
      
      case BookingStep.CONFIRMATION:
        return (
          <div className="text-center py-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-2">¡Reserva Confirmada!</h3>
            <p className="text-gray-600 mb-6">
              Hemos enviado el contrato digital y las instrucciones de acceso a <strong>{data.customer.email}</strong>.
            </p>
            <div className="bg-gray-50 p-4 rounded text-left text-sm text-gray-600 space-y-2 mb-6">
                <p><strong>Referencia:</strong> #CS-{Math.floor(Math.random()*10000)}</p>
                <p><strong>Unidad:</strong> {selectedUnit?.sizeLabel}</p>
                <p><strong>Inicio:</strong> {data.startDate}</p>
            </div>
            <Button onClick={onClose} fullWidth>Volver al inicio</Button>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        {/* Backdrop */}
        <div className="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity" onClick={onClose} aria-hidden="true"></div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        {/* Modal Panel */}
        <div className="inline-block align-bottom bg-white rounded-2xl text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg w-full">
          
          {/* Header */}
          <div className="bg-brand-900 px-4 py-3 sm:px-6 flex justify-between items-center">
            <h3 className="text-lg leading-6 font-medium text-white flex items-center gap-2">
               {step === BookingStep.CONFIRMATION ? 'Todo listo' : 'Reserva tu espacio'}
            </h3>
            <button onClick={onClose} className="text-gray-400 hover:text-white focus:outline-none">
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Progress Bar (if not done) */}
          {step !== BookingStep.CONFIRMATION && (
            <div className="w-full bg-gray-200 h-1">
                <div 
                    className="bg-accent-500 h-1 transition-all duration-300" 
                    style={{ width: `${((step + 1) / 4) * 100}%` }}
                ></div>
            </div>
          )}

          {/* Body */}
          <div className="px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
             {renderStep()}
          </div>

          {/* Footer */}
          {step !== BookingStep.CONFIRMATION && (
            <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse gap-2">
              <Button 
                onClick={step === BookingStep.PAYMENT ? simulatePayment : handleNext} 
                disabled={(step === BookingStep.SELECT_DATES && !data.startDate) || isProcessing}
                fullWidth
                className="w-full sm:w-auto"
              >
                {isProcessing ? 'Procesando...' : step === BookingStep.PAYMENT ? 'Pagar y Firmar' : 'Continuar'}
              </Button>
              
              {step > 0 && (
                 <Button 
                   onClick={handleBack} 
                   variant="outline"
                   fullWidth
                   className="mt-3 sm:mt-0 w-full sm:w-auto"
                 >
                   Atrás
                 </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
