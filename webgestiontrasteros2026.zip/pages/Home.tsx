import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Clock, Camera, Key, CheckCircle2, ArrowRight } from 'lucide-react';
import { UNIT_SIZES, TESTIMONIALS, USE_CASES } from '../constants';
import * as Icons from 'lucide-react';

export const Home: React.FC = () => {
  return (
    <div className="bg-white">
      {/* HERO SECTION */}
      <section className="relative bg-slate-900 text-white py-20 lg:py-32 overflow-hidden">
        {/* Background Overlay Image */}
        <div className="absolute inset-0 z-0 opacity-20">
             <img 
                src="https://picsum.photos/1920/1080?grayscale" 
                alt="Almacén industrial fondo" 
                className="w-full h-full object-cover"
             />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6">
            Tu Espacio Extra en <span className="text-brand-500">Cantabria</span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto mb-10 font-light">
            Alquiler de trasteros seguros, limpios y accesibles 24h. 
            La solución perfecta para tu hogar o empresa, sin permanencia.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link 
              to="/reservar" 
              className="bg-brand-600 hover:bg-brand-700 text-white text-lg font-bold py-4 px-10 rounded-full shadow-xl shadow-brand-900/50 transition-all transform hover:scale-105"
            >
              Consultar Disponibilidad
            </Link>
            <a 
              href="#tamanos" 
              className="bg-transparent border-2 border-white hover:bg-white hover:text-slate-900 text-white text-lg font-semibold py-4 px-10 rounded-full transition-all"
            >
              Ver Tamaños y Precios
            </a>
          </div>
          
          {/* Trust Badges */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm font-medium text-slate-300">
             <div className="flex flex-col items-center gap-2">
                <Clock className="text-brand-400" size={32} />
                <span>Acceso 24 Horas</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <Camera className="text-brand-400" size={32} />
                <span>Videovigilancia CCTV</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <Shield className="text-brand-400" size={32} />
                <span>Seguro Incluido</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <Key className="text-brand-400" size={32} />
                <span>Código Personal</span>
             </div>
          </div>
        </div>
      </section>

      {/* USE CASES SECTION */}
      <section className="py-20 bg-gray-50" id="beneficios">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">¿Qué necesitas guardar?</h2>
                <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                    Nuestros espacios se adaptan a cualquier necesidad, tanto si eres particular como profesional.
                </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {USE_CASES.map((uc, idx) => {
                    // Dynamic icon rendering
                    const IconComponent = (Icons as any)[uc.iconName] || Icons.Box;
                    return (
                        <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                            <div className="bg-brand-50 w-14 h-14 rounded-xl flex items-center justify-center mb-6">
                                <IconComponent className="text-brand-600" size={28} />
                            </div>
                            <h3 className="text-xl font-bold text-slate-900 mb-3">{uc.title}</h3>
                            <p className="text-slate-600 leading-relaxed">
                                {uc.description}
                            </p>
                        </div>
                    );
                })}
            </div>
        </div>
      </section>

      {/* SIZES & PRICING */}
      <section className="py-20 bg-white" id="tamanos">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Tamaños y Precios</h2>
                <p className="text-lg text-slate-600">
                    Transparencia total. Sin costes ocultos. Reserva tu espacio ideal.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {UNIT_SIZES.map((unit) => (
                    <div key={unit.id} className="relative group bg-white border border-gray-200 rounded-2xl overflow-hidden hover:border-brand-500 transition-all hover:shadow-xl hover:-translate-y-1">
                        <div className="p-8">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h3 className="text-2xl font-bold text-slate-900">{unit.dimensions}</h3>
                                    <span className="inline-block bg-gray-100 text-slate-600 text-xs px-2 py-1 rounded mt-1 font-medium">
                                        {unit.area} m² superficie
                                    </span>
                                </div>
                                <div className="text-right">
                                    <span className="text-3xl font-bold text-brand-600">{unit.price}€</span>
                                    <span className="text-gray-500 text-sm block">/mes + IVA</span>
                                </div>
                            </div>
                            
                            <p className="text-slate-600 mb-6 min-h-[3rem]">
                                {unit.description}
                            </p>

                            <div className="space-y-3 mb-8">
                                <p className="text-sm font-semibold text-slate-900 uppercase tracking-wide">Recomendado para:</p>
                                {unit.recommendedFor.map((rec, i) => (
                                    <div key={i} className="flex items-center gap-2 text-sm text-slate-600">
                                        <CheckCircle2 size={16} className="text-green-500 flex-shrink-0" />
                                        <span>{rec}</span>
                                    </div>
                                ))}
                            </div>

                            <Link 
                                to={`/reservar?unit=${unit.id}`}
                                className="block w-full py-3 px-4 bg-slate-900 text-white text-center font-semibold rounded-lg group-hover:bg-brand-600 transition-colors"
                            >
                                Seleccionar
                            </Link>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 bg-slate-50 border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
             <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-slate-900">Lo que dicen nuestros clientes</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {TESTIMONIALS.map((t) => (
                    <div key={t.id} className="bg-white p-8 rounded-xl shadow-sm italic">
                        <div className="flex items-center gap-1 text-yellow-400 mb-4">
                            {[1,2,3,4,5].map(star => <span key={star}>★</span>)}
                        </div>
                        <p className="text-slate-700 mb-6">"{t.text}"</p>
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold">
                                {t.name.charAt(0)}
                            </div>
                            <div>
                                <h4 className="font-bold text-slate-900 text-sm">{t.name}</h4>
                                <span className="text-slate-500 text-xs">{t.role}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-20 bg-brand-700 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">¿Listo para liberar espacio?</h2>
            <p className="text-xl text-brand-100 mb-10">
                Contrata online en menos de 5 minutos y accede a tu trastero hoy mismo.
                Sin fianza y sin compromiso de permanencia.
            </p>
            <Link 
                to="/reservar"
                className="inline-flex items-center gap-2 bg-white text-brand-700 hover:bg-brand-50 font-bold text-lg py-4 px-8 rounded-lg shadow-lg transition-all"
            >
                Empezar Reserva <ArrowRight size={20} />
            </Link>
        </div>
      </section>
    </div>
  );
};