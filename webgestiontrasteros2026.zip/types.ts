export interface UnitSize {
  id: string;
  dimensions: string; // e.g., "2x1 m"
  area: number; // m2
  price: number; // Monthly price
  description: string;
  recommendedFor: string[];
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  text: string;
}

export interface UseCase {
  title: string;
  description: string;
  iconName: string;
}

export interface UserBookingData {
  unitId: string | null;
  startDate: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  paymentMethod: 'card' | 'transfer';
}