import { UnitSize, Testimonial, UseCase } from './types';
import { Archive, Bike, Briefcase, Box, Wrench } from 'lucide-react';

export const UNIT_SIZES: UnitSize[] = [
  {
    id: 'u-2x1',
    dimensions: '2x1 m',
    area: 2,
    price: 45,
    description: 'Ideal para cajas, maletas o bicicletas.',
    recommendedFor: ['Estudiantes', 'Invierno', 'Archivos'],
  },
  {
    id: 'u-2x1.5',
    dimensions: '2x1.5 m',
    area: 3,
    price: 60,
    description: 'Perfecto para guardar enseres de una habitación pequeña.',
    recommendedFor: ['Mudanza pequeña', 'Material deportivo'],
  },
  {
    id: 'u-2x2',
    dimensions: '2x2 m',
    area: 4,
    price: 75,
    description: 'Capacidad para muebles de un dormitorio completo.',
    recommendedFor: ['Reformas', 'Stock pequeño'],
  },
  {
    id: 'u-2x2.5',
    dimensions: '2x2.5 m',
    area: 5,
    price: 90,
    description: 'Espacio versátil para hogar o negocio.',
    recommendedFor: ['Muebles salón', 'Herramientas'],
  },
  {
    id: 'u-3x2',
    dimensions: '3x2 m',
    area: 6,
    price: 105,
    description: 'Gran capacidad. Apartamento de 1 habitación.',
    recommendedFor: ['Mudanza completa', 'Archivo empresa'],
  },
  {
    id: 'u-4x2',
    dimensions: '4x2 m',
    area: 8,
    price: 135,
    description: 'Nuestro almacén más grande. Ideal profesionales.',
    recommendedFor: ['Stock comercial', 'Logística', 'Piso 2 hab'],
  },
];

export const USE_CASES: UseCase[] = [
  {
    title: 'Guardamuebles Temporal',
    description: 'La solución perfecta durante reformas o mudanzas. Mantén tus muebles seguros y secos.',
    iconName: 'Box',
  },
  {
    title: 'Archivos y Documentación',
    description: 'Libera espacio en tu oficina archivando documentación antigua de forma segura y accesible.',
    iconName: 'Archive',
  },
  {
    title: 'Material Deportivo',
    description: 'Bicicletas, tablas de surf, esquís... Tu equipamiento listo para la próxima aventura en Cantabria.',
    iconName: 'Bike',
  },
  {
    title: 'Stock Comercial',
    description: 'Mini-almacenes logísticos para e-commerce y tiendas físicas. Recepción de mercancía.',
    iconName: 'Briefcase',
  },
  {
    title: 'Herramientas',
    description: 'Espacio seguro para autónomos y contratistas. Acceso 24h para coger lo que necesites.',
    iconName: 'Wrench',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: 'Carlos Ruiz',
    role: 'Arquitecto Técnico',
    text: 'Necesitaba un sitio seguro para mis herramientas y materiales. El acceso 24h es fundamental para mi trabajo. Excelente servicio.',
  },
  {
    id: 2,
    name: 'María Fernández',
    role: 'Particular (Mudanza)',
    text: 'El proceso de contratación fue súper rápido. Pude reservar desde el móvil y entrar al trastero en menos de 1 hora. Muy limpio.',
  },
  {
    id: 3,
    name: 'Gestoría López',
    role: 'Empresa',
    text: 'Usamos webCantabriaStorage para nuestro archivo pasivo. La seguridad y videovigilancia nos dan total tranquilidad.',
  },
];